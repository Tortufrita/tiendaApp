package com.prueba.tiendaapp.data.product.network

import com.prueba.tiendaapp.data.product.dto.ProductDto
import retrofit2.http.GET

interface ProductApi {
    @GET("/foods")
    suspend fun getProducts(): List<ProductDto>
}