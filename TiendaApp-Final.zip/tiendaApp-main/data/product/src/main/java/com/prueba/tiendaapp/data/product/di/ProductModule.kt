package com.prueba.tiendaapp.data.product.di

import com.prueba.tiendaapp.domain.product.ProductRepository
import com.prueba.tiendaapp.data.product.ProductRepositoryImpl
import com.prueba.tiendaapp.data.product.network.ProductApi
import com.prueba.tiendaapp.data.database.dao.ProductDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import retrofit2.Retrofit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object ProductModule {

    @Provides
    @Singleton
    fun provideProductApi(retrofit: Retrofit): ProductApi = retrofit.create(ProductApi::class.java)

    @Provides
    @Singleton
    fun provideProductRepository(productApi: ProductApi, productDao: ProductDao): ProductRepository = ProductRepositoryImpl(productApi, productDao)
}