package com.prueba.tiendaapp.data.product.dto

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class ProductDto(
    @Json(name = "_id")   val id: String,
    val name: String,
    val description: String,
    val imageUrl: String,
    val price: Double,
    val category: String? = "Sin categoría",
    @Json(name = "hasDrink") val hasDrink: Boolean? = false,
    val createdAt: String,
    val updatedAt: String
)