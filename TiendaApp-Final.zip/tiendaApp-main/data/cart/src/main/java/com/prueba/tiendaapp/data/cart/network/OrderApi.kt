package com.prueba.tiendaapp.data.cart.network

import com.prueba.tiendaapp.data.cart.dto.OrderDto
import com.prueba.tiendaapp.data.cart.dto.OrderResponse
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

interface OrderApi {
    @POST("orders")
    suspend fun createOrder(@Body order: OrderDto): Response<OrderResponse>
    
    @GET("orders")
    suspend fun getOrders(): Response<List<OrderResponse>>
}