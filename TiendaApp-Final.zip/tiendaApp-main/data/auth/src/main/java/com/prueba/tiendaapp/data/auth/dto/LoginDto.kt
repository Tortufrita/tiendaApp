package com.prueba.tiendaapp.data.auth.dto

data class LoginDto(
    val email: String,
    val encryptedPassword: String
)