package com.prueba.tiendaapp.domain.product

import com.prueba.tiendaapp.core.model.Product
import kotlinx.coroutines.flow.Flow

interface ProductRepository {
    fun getProducts(): Flow<List<Product>>
    suspend fun getProductById(productId: String): Product?
    suspend fun syncProductsFromApi(): List<Product>
    suspend fun refreshProducts(): List<Product>
    suspend fun hasLocalProducts(): Boolean
}