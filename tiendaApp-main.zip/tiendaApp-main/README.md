**TiendaApp** es una aplicación móvil desarrollada en Android con Kotlin y Jetpack Compose.
Permite explorar productos, gestionar un carrito de compras, ver historial de órdenes,
subir imágenes de perfil y mucho más.

---

## 🚀 Funcionalidades

- 🔐 Inicio de sesión y registro con validaciones
- 📦 Catálogo de productos con búsqueda
- 🛍️ Carrito de compras (agregar, editar, eliminar)
- 🧾 Historial de compras
- 🖼️ Subida de imágenes a Cloudinary (perfil)
- 👤 Edición de perfil
---

## 🧩 Tecnologías

- Jetpack Compose
- MVVM + Hilt
- Room (persistencia local)
- Retrofit (API REST)

---

## ⚙️ Configuración

1. Clona o descarga el repositorio
2. Asegúrate de agregar tu `RENDER_BASE_URL` en `local.properties`
3. Ejecuta el proyecto en Android Studio

---

## 📁 Estructura Modular

- `app`: punto de entrada
- `data`: lógica de red y persistencia
- `ui`: componentes visuales