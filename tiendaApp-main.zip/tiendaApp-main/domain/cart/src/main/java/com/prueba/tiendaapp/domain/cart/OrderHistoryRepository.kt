package com.prueba.tiendaapp.domain.cart

import com.prueba.tiendaapp.core.model.CartItem
import com.prueba.tiendaapp.core.model.Order

interface OrderHistoryRepository {
    suspend fun getOrders(): List<Order>
    suspend fun addOrder(cartItems: List<CartItem>): Order?
    fun clearHistory()
}