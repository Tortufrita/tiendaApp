package com.prueba.tiendaapp.domain.cart

import com.prueba.tiendaapp.core.model.CartItem
import com.prueba.tiendaapp.core.model.Product

interface CartItemRepository {
    fun getCartItems(): List<CartItem>
    fun addProduct(product: Product)
    fun removeProduct(product: Product)
    fun updateQuantity(product: Product, quantity: Int)
    fun clearCart()
}