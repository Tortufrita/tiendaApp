package com.prueba.tiendaapp.core.cloudinary

data class CloudinaryConfig(
    val cloudName: String,
    val apiKey: String,
    val apiSecret: String
)