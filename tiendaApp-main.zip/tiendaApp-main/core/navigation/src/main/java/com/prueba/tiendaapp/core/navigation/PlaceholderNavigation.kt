package com.prueba.tiendaapp.core.navigation

// Placeholder file to ensure module compilation
// Navigation helpers will be migrated from the main module