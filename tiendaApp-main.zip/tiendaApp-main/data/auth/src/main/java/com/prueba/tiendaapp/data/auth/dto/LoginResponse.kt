package com.prueba.tiendaapp.data.auth.dto

import com.prueba.tiendaapp.core.model.User

data class LoginResponse(
    val message: String,
    val user: User? = null
)