package com.prueba.tiendaapp.data.cart.di

import com.prueba.tiendaapp.domain.cart.CartItemRepository
import com.prueba.tiendaapp.domain.cart.OrderHistoryRepository
import com.prueba.tiendaapp.data.cart.CartItemRepositoryImpl
import com.prueba.tiendaapp.data.cart.OrderHistoryRepositoryImpl
import com.prueba.tiendaapp.data.cart.network.OrderApi
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import retrofit2.Retrofit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object CartModule {

    @Provides
    @Singleton
    fun provideOrderApi(retrofit: Retrofit): OrderApi = retrofit.create(OrderApi::class.java)

    @Provides
    @Singleton
    fun provideCartItemRepository(impl: CartItemRepositoryImpl): CartItemRepository = impl

    @Provides
    @Singleton
    fun provideOrderHistoryRepository(impl: OrderHistoryRepositoryImpl): OrderHistoryRepository = impl
}