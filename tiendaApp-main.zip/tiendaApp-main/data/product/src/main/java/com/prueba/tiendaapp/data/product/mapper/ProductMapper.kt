package com.prueba.tiendaapp.data.product.mapper

import com.prueba.tiendaapp.data.product.dto.ProductDto
import com.prueba.tiendaapp.core.model.Product

fun ProductDto.toDomain() = Product(
    id          = id,
    name        = name,
    description = description,
    price       = price,
    imageUrl    = imageUrl,
    category    = category ?: "Sin categoría",
    includesDrink = hasDrink ?: false
)